
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  // Accounts
  const cash = await prisma.account.upsert({
    where: { id: 'seed_cash' },
    update: {},
    create: { id: 'seed_cash', name: 'Caixa Físico', type: 'CASH' }
  });
  const bank = await prisma.account.upsert({
    where: { id: 'seed_bank' },
    update: {},
    create: { id: 'seed_bank', name: 'Conta Corrente', type: 'BANK' }
  });

  // Products
  const paoFrances = await prisma.product.upsert({
    where: { id: 'prd_pao_frances' },
    update: { name: 'Pão Francês', price: 1.20, avgCost: 0.65 },
    create: { id: 'prd_pao_frances', name: 'Pão Francês', price: 1.20, avgCost: 0.65 }
  });
  const paoCaseiro = await prisma.product.upsert({
    where: { id: 'prd_pao_caseiro' },
    update: { name: 'Pão Caseiro', price: 8.50 },
    create: { id: 'prd_pao_caseiro', name: 'Pão Caseiro', price: 8.50 }
  });

  // Ingredients
  const farinha = await prisma.ingredient.upsert({
    where: { id: 'ing_farinha_t1' },
    update: { name: 'Farinha Tipo 1', unit: 'kg', minStock: 5 },
    create: { id: 'ing_farinha_t1', name: 'Farinha Tipo 1', unit: 'kg', minStock: 5 }
  });

  // Initial stock movement for ingredient
  await prisma.stockMovement.create({
    data: {
      itemType: 'INGREDIENT',
      itemId: farinha.id,
      direction: 'IN',
      qty: 50, // 50 kg
      originType: 'SEED',
      originId: 'seed_init'
    }
  });

  // BOM for Pão Francês: 0.05 kg por unidade (50g)
  const bom = await prisma.bom.upsert({
    where: { productId: paoFrances.id },
    update: {},
    create: { productId: paoFrances.id }
  });
  await prisma.bomItem.upsert({
    where: { id: 'bomitem_pf_farinha' },
    update: { factor: 0.05 },
    create: { id: 'bomitem_pf_farinha', bomId: bom.id, ingredientId: farinha.id, factor: 0.05 }
  });

  console.log('Seed completed');
}

main().finally(() => prisma.$disconnect());
