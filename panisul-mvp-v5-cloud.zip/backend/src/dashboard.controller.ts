
import { Controller, Get } from '@nestjs/common';
import { PrismaService } from './prisma.service';

function startOfDay(d = new Date()) {
  const x = new Date(d);
  x.setHours(0,0,0,0);
  return x;
}
function endOfDay(d = new Date()) {
  const x = new Date(d);
  x.setHours(23,59,59,999);
  return x;
}

@Controller('dashboard')
export class DashboardController {
  constructor(private prisma: PrismaService) {}

  @Get('kpis')
  async kpis() {
    // Balances
    const [cashIn, cashOut, bankIn, bankOut] = await Promise.all([
      this.prisma.transaction.aggregate({ where: { account: { type: 'CASH' }, direction: 'IN' }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { account: { type: 'CASH' }, direction: 'OUT' }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { account: { type: 'BANK' }, direction: 'IN' }, _sum: { amount: true } }),
      this.prisma.transaction.aggregate({ where: { account: { type: 'BANK' }, direction: 'OUT' }, _sum: { amount: true } }),
    ]);
    const cashBalance = (cashIn._sum.amount ?? 0) - (cashOut._sum.amount ?? 0);
    const bankBalance = (bankIn._sum.amount ?? 0) - (bankOut._sum.amount ?? 0);

    // Today summaries
    const s = startOfDay(); const e = endOfDay();
    const [salesTxToday, producedItems, exchangesCount] = await Promise.all([
      this.prisma.transaction.aggregate({ where: { originType: 'SALE', occurredAt: { gte: s, lte: e }, direction: 'IN' }, _sum: { amount: true } }),
      this.prisma.stockMovement.aggregate({ where: { itemType: 'PRODUCT', direction: 'IN', originType: 'PRODUCTION_OUTPUT', occurredAt: { gte: s, lte: e } }, _sum: { qty: true } }),
      this.prisma.exchange.count({ where: { createdAt: { gte: s, lte: e } } }),
    ]);

    return {
      kpis: {
        cash_balance: Number(cashBalance),
        bank_balance: Number(bankBalance),
        receivables_due_today: 0,
        payables_due_today: 0
      },
      summary_today: {
        sales_total: Number(salesTxToday._sum.amount ?? 0),
        produced_items: Number(producedItems._sum.qty ?? 0),
        exchanges_count: exchangesCount
      },
      alerts: [],
      timestamp: new Date().toISOString(),
    };
  }
}
