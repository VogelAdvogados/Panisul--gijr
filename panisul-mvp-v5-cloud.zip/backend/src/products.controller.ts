
import { Controller, Get } from '@nestjs/common';
import { PrismaService } from './prisma.service';

@Controller('products')
export class ProductsController {
  constructor(private prisma: PrismaService) {}

  @Get()
  async list() {
    return this.prisma.product.findMany({ orderBy: { name: 'asc' } });
  }
}
