
import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { PrismaService } from './prisma.service';

@Controller('payables')
export class PayablesController {
  constructor(private prisma: PrismaService) {}

  @Get()
  async list() {
    return this.prisma.payable.findMany({ orderBy: { dueDate: 'asc' } });
  }

  @Post()
  async create(@Body() body: { supplier: string; dueDate: string; amount: number; }) {
    const p = await this.prisma.payable.create({ data: { supplier: body.supplier, dueDate: new Date(body.dueDate), amount: body.amount } });
    return p;
  }

  @Post(':id/settle')
  async settle(@Param('id') id: string, @Body() body: { accountType: 'CASH'|'BANK'; method?: string; }) {
    const payable = await this.prisma.payable.findFirstOrThrow({ where: { id } });
    if (payable.status !== 'OPEN') throw new Error('Already settled/canceled');
    const account = await this.prisma.account.findFirstOrThrow({ where: { type: body.accountType as any } });

    await this.prisma.$transaction([
      this.prisma.payable.update({ where: { id }, data: { status: 'PAID', paidAt: new Date(), accountId: account.id } }),
      this.prisma.transaction.create({ data: { accountId: account.id, direction: 'OUT', amount: payable.amount, originType: 'PAYABLE', originId: id, note: body.method ?? 'Baixa de despesa' } })
    ]);

    return { ok: true };
  }
}
