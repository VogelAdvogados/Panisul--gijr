
import { Body, Controller, HttpException, HttpStatus, Post } from '@nestjs/common';
import { PrismaService } from './prisma.service';

type ExchangeDto = {
  customer: string;
  productId: string;
  qtyOut: number;
  returnedProductId?: string | null;
  returnedQty?: number | null;
  reason?: string | null;
};

@Controller('exchanges')
export class ExchangesController {
  constructor(private prisma: PrismaService) {}

  private async getStock(itemType: 'PRODUCT'|'INGREDIENT', itemId: string) {
    const [inSum, outSum, wasteSum] = await Promise.all([
      this.prisma.stockMovement.aggregate({ where: { itemType, itemId, direction: 'IN' }, _sum: { qty: true } }),
      this.prisma.stockMovement.aggregate({ where: { itemType, itemId, direction: 'OUT' }, _sum: { qty: true } }),
      this.prisma.stockMovement.aggregate({ where: { itemType, itemId, direction: 'WASTE' }, _sum: { qty: true } }),
    ]);
    const total = Number(inSum._sum.qty ?? 0) - Number(outSum._sum.qty ?? 0) - Number(wasteSum._sum.qty ?? 0);
    return total;
  }

  @Post()
  async create(@Body() body: ExchangeDto) {
    const { customer, productId, qtyOut } = body;
    if (!customer || !productId || !qtyOut || qtyOut <= 0) {
      throw new HttpException('Campos obrigatórios: customer, productId, qtyOut>0', HttpStatus.BAD_REQUEST);
    }

    const product = await this.prisma.product.findFirst({ where: { id: productId } });
    if (!product) throw new HttpException('Produto não encontrado', HttpStatus.NOT_FOUND);

    const stock = await this.getStock('PRODUCT', productId);
    if (stock < qtyOut) throw new HttpException(`Estoque insuficiente do produto: necessário ${qtyOut}, disponível ${stock}`, HttpStatus.BAD_REQUEST);

    const returnedProductId = body.returnedProductId ?? null;
    const returnedQty = Number(body.returnedQty ?? 0);
    const costAmount = Number(product.avgCost) * qtyOut;

    const result = await this.prisma.$transaction(async (tx) => {
      const exg = await tx.exchange.create({
        data: {
          customer, productId, qtyOut, returnedProductId, returnedQty: returnedQty || null, reason: body.reason ?? null, costAmount
        }
      });

      // Deduct delivered product
      await tx.stockMovement.create({
        data: { itemType: 'PRODUCT', itemId: productId, direction: 'OUT', qty: qtyOut, originType: 'EXCHANGE_DELIVER', originId: exg.id }
      });

      // Returned product goes to waste (if any)
      if (returnedProductId && returnedQty > 0) {
        await tx.stockMovement.create({
          data: { itemType: 'PRODUCT', itemId: returnedProductId, direction: 'WASTE', qty: returnedQty, originType: 'EXCHANGE_RETURN_WASTE', originId: exg.id }
        });
      }

      return exg;
    });

    const stockAfter = await this.getStock('PRODUCT', productId);
    return { id: result.id, costAmount, product: { id: product.id, name: product.name, stockAfter }, message: 'Troca registrada sem transação monetária.' };
  }
}
