
import { Module } from '@nestjs/common';
import { DashboardController } from './dashboard.controller';
import { AccountsController } from './accounts.controller';
import { PayablesController } from './payables.controller';
import { ReceivablesController } from './receivables.controller';
import { SalesController } from './sales.controller';
import { ProductionController } from './production.controller';
import { PrismaService } from './prisma.service';
import { ProductsController } from './products.controller';
import { ExchangesController } from './exchanges.controller';

@Module({
  imports: [],
  controllers: [DashboardController, SalesController, ProductionController, AccountsController, PayablesController, ReceivablesController, ProductsController, ExchangesController],
  providers: [PrismaService],
})
export class AppModule {}
