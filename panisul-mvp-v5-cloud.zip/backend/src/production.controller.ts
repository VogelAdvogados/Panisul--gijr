
import { Body, Controller, HttpException, HttpStatus, Post } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { Prisma } from '@prisma/client';

@Controller('production-batches')
export class ProductionController {
  constructor(private prisma: PrismaService) {}

  // Helper: current stock for an item
  private async getStock(itemType: 'PRODUCT'|'INGREDIENT', itemId: string) {
    const [inSum, outSum, wasteSum] = await Promise.all([
      this.prisma.stockMovement.aggregate({ where: { itemType, itemId, direction: 'IN' }, _sum: { qty: true } }),
      this.prisma.stockMovement.aggregate({ where: { itemType, itemId, direction: 'OUT' }, _sum: { qty: true } }),
      this.prisma.stockMovement.aggregate({ where: { itemType, itemId, direction: 'WASTE' }, _sum: { qty: true } }),
    ]);
    const total = Number(inSum._sum.qty ?? 0) - Number(outSum._sum.qty ?? 0) - Number(wasteSum._sum.qty ?? 0);
    return total;
  }

  @Post()
  async create(@Body() body: { productId: string; qtyProduced: number; qtyLosses?: number }) {
    const qtyProduced = Number(body.qtyProduced);
    const qtyLosses = Number(body.qtyLosses ?? 0);
    if (!body.productId || qtyProduced <= 0) {
      throw new HttpException('productId e qtyProduced são obrigatórios e > 0', HttpStatus.BAD_REQUEST);
    }

    const product = await this.prisma.product.findFirst({ where: { id: body.productId } });
    if (!product) throw new HttpException('Produto não encontrado', HttpStatus.NOT_FOUND);

    const bom = await this.prisma.bom.findFirst({ where: { productId: product.id }, include: { items: { include: { ingredient: true } } } });
    if (!bom || bom.items.length === 0) {
      throw new HttpException('Ficha técnica (BOM) inexistente para o produto', HttpStatus.BAD_REQUEST);
    }

    // Compute required ingredients
    const required = bom.items.map(i => ({
      ingredientId: i.ingredientId,
      name: i.ingredient.name,
      qty: Number(i.factor) * qtyProduced
    }));

    // Validate stock for each ingredient
    for (const r of required) {
      const stock = await this.getStock('INGREDIENT', r.ingredientId);
      if (stock < r.qty) {
        throw new HttpException(`Estoque insuficiente para ${r.name}: necessário ${r.qty.toFixed(3)}, disponível ${stock.toFixed(3)}`, HttpStatus.BAD_REQUEST);
      }
    }

    // Transaction: create production batch + stock movements (consume ingredients, add product, register waste)
    const result = await this.prisma.$transaction(async (tx) => {
      const batch = await tx.productionBatch.create({
        data: { productId: product.id, qtyProduced, qtyLosses }
      });

      // Consume ingredients
      for (const r of required) {
        await tx.stockMovement.create({
          data: {
            itemType: 'INGREDIENT',
            itemId: r.ingredientId,
            direction: 'OUT',
            qty: r.qty,
            originType: 'PRODUCTION_CONSUME',
            originId: batch.id
          }
        });
      }

      // Add finished product
      await tx.stockMovement.create({
        data: {
          itemType: 'PRODUCT',
          itemId: product.id,
          direction: 'IN',
          qty: qtyProduced,
          originType: 'PRODUCTION_OUTPUT',
          originId: batch.id
        }
      });

      // Losses (waste) of finished product
      if (qtyLosses > 0) {
        await tx.stockMovement.create({
          data: {
            itemType: 'PRODUCT',
            itemId: product.id,
            direction: 'WASTE',
            qty: qtyLosses,
            originType: 'PRODUCTION_LOSS',
            originId: batch.id
          }
        });
      }

      return batch;
    });

    // Return summary including updated stock
    const productStock = await this.getStock('PRODUCT', product.id);
    const ingStocks = await Promise.all(required.map(async r => ({
      ingredientId: r.ingredientId,
      name: r.name,
      stock: await this.getStock('INGREDIENT', r.ingredientId)
    })));

    return {
      id: result.id,
      product: { id: product.id, name: product.name, stock: productStock },
      produced: qtyProduced,
      losses: qtyLosses,
      consumed: required,
      remaining: ingStocks
    };
  }
}
