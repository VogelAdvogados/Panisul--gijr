
import { Body, Controller, HttpException, HttpStatus, Post } from '@nestjs/common';
import { PrismaService } from './prisma.service';

type SaleItemDto = { productId: string; qty: number; unitPrice?: number };
type PaymentMethod = 'CASH' | 'PIX' | 'CARD' | 'ON_CREDIT';
type SaleDto = {
  customer?: string;
  items: SaleItemDto[];
  payment: { method: PaymentMethod; dueDate?: string };
};

@Controller('sales')
export class SalesController {
  constructor(private prisma: PrismaService) {}

  private async getStockProduct(productId: string) {
    const [inSum, outSum, wasteSum] = await Promise.all([
      this.prisma.stockMovement.aggregate({ where: { itemType: 'PRODUCT', itemId: productId, direction: 'IN' }, _sum: { qty: true } }),
      this.prisma.stockMovement.aggregate({ where: { itemType: 'PRODUCT', itemId: productId, direction: 'OUT' }, _sum: { qty: true } }),
      this.prisma.stockMovement.aggregate({ where: { itemType: 'PRODUCT', itemId: productId, direction: 'WASTE' }, _sum: { qty: true } }),
    ]);
    return Number(inSum._sum.qty ?? 0) - Number(outSum._sum.qty ?? 0) - Number(wasteSum._sum.qty ?? 0);
  }

  @Post()
  async create(@Body() body: SaleDto) {
    if (!body.items || body.items.length === 0) throw new HttpException('Itens obrigatórios', HttpStatus.BAD_REQUEST);
    if (!body.payment || !body.payment.method) throw new HttpException('Forma de pagamento obrigatória', HttpStatus.BAD_REQUEST);

    // Load products and compute totals
    const productIds = [...new Set(body.items.map(i => i.productId))];
    const products = await this.prisma.product.findMany({ where: { id: { in: productIds } } });
    if (products.length !== productIds.length) throw new HttpException('Produto inválido', HttpStatus.BAD_REQUEST);

    let total = 0;
    for (const it of body.items) {
      if (it.qty <= 0) throw new HttpException('Quantidade deve ser > 0', HttpStatus.BAD_REQUEST);
      const prod = products.find(p => p.id === it.productId)!;
      const price = it.unitPrice ?? Number(prod.price);
      total += price * it.qty;
      // Stock validation
      const stock = await this.getStockProduct(it.productId);
      if (stock < it.qty) throw new HttpException(`Estoque insuficiente para ${prod.name}. Disponível: ${stock}`, HttpStatus.BAD_REQUEST);
    }

    const accountType = body.payment.method === 'CASH' ? 'CASH' : (body.payment.method === 'ON_CREDIT' ? null : 'BANK');

    const created = await this.prisma.$transaction(async (tx) => {
      // Create sale + items
      const sale = await tx.sale.create({ data: { customer: body.customer ?? null, total } });
      for (const it of body.items) {
        const prod = products.find(p => p.id === it.productId)!;
        const price = it.unitPrice ?? Number(prod.price);
        await tx.saleItem.create({ data: { saleId: sale.id, productId: prod.id, qty: it.qty, unitPrice: price } });
        // stock OUT
        await tx.stockMovement.create({ data: { itemType: 'PRODUCT', itemId: prod.id, direction: 'OUT', qty: it.qty, originType: 'SALE', originId: sale.id } });
      }

      if (body.payment.method === 'ON_CREDIT') {
        // Create receivable
        const dueDate = body.payment.dueDate ? new Date(body.payment.dueDate) : new Date();
        await tx.receivable.create({ data: { customer: body.customer ?? 'Cliente', dueDate, amount: total } });
      } else if (accountType) {
        // Financial transaction IN
        const acc = await tx.account.findFirstOrThrow({ where: { type: accountType as any } });
        await tx.transaction.create({ data: { accountId: acc.id, direction: 'IN', amount: total, originType: 'SALE', originId: 'sale', note: 'Recebido na venda' } });
      }

      return sale;
    });

    return { id: created.id, total, payment: body.payment.method };
  }
}
