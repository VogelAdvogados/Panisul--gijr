
import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { PrismaService } from './prisma.service';

@Controller('receivables')
export class ReceivablesController {
  constructor(private prisma: PrismaService) {}

  @Get()
  async list() {
    return this.prisma.receivable.findMany({ orderBy: { dueDate: 'asc' } });
  }

  @Post()
  async create(@Body() body: { customer: string; dueDate: string; amount: number; }) {
    const r = await this.prisma.receivable.create({ data: { customer: body.customer, dueDate: new Date(body.dueDate), amount: body.amount } });
    return r;
  }

  @Post(':id/settle')
  async settle(@Param('id') id: string, @Body() body: { accountType: 'CASH'|'BANK'; method?: string; }) {
    const receivable = await this.prisma.receivable.findFirstOrThrow({ where: { id } });
    if (receivable.status !== 'OPEN') throw new Error('Already settled/canceled');
    const account = await this.prisma.account.findFirstOrThrow({ where: { type: body.accountType as any } });

    await this.prisma.$transaction([
      this.prisma.receivable.update({ where: { id }, data: { status: 'PAID', receivedAt: new Date(), accountId: account.id } }),
      this.prisma.transaction.create({ data: { accountId: account.id, direction: 'IN', amount: receivable.amount, originType: 'RECEIVABLE', originId: id, note: body.method ?? 'Baixa de recebível' } })
    ]);

    return { ok: true };
  }
}
