
import { Body, Controller, Get, Post } from '@nestjs/common';
import { PrismaService } from './prisma.service';

@Controller('accounts')
export class AccountsController {
  constructor(private prisma: PrismaService) {}

  @Get()
  async list() {
    const accounts = await this.prisma.account.findMany({ orderBy: { name: 'asc' } });
    return accounts;
  }

  @Post('transfer')
  async transfer(@Body() body: { from?: string; to?: string; fromType?: 'CASH'|'BANK'; toType?: 'CASH'|'BANK'; amount: number; note?: string; }) {
    // Allow either by account id or by type shortcut
    const fromAcc = body.from
      ? await this.prisma.account.findFirstOrThrow({ where: { id: body.from } })
      : await this.prisma.account.findFirstOrThrow({ where: { type: body.fromType as any } });
    const toAcc = body.to
      ? await this.prisma.account.findFirstOrThrow({ where: { id: body.to } })
      : await this.prisma.account.findFirstOrThrow({ where: { type: body.toType as any } });

    if (fromAcc.id === toAcc.id) throw new Error('Accounts must be different');
    if (body.amount <= 0) throw new Error('Amount must be > 0');

    const txOut = await this.prisma.transaction.create({
      data: { accountId: fromAcc.id, direction: 'OUT', amount: body.amount, originType: 'TRANSFER', originId: 'link', note: body.note ?? 'Transferência' }
    });
    const txIn = await this.prisma.transaction.create({
      data: { accountId: toAcc.id, direction: 'IN', amount: body.amount, originType: 'TRANSFER', originId: txOut.id, note: body.note ?? 'Transferência' }
    });

    return { transferId: txOut.id, entries: [txOut, txIn] };
  }
}
