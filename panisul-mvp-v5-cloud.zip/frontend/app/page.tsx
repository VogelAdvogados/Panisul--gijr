
'use client';
import { useEffect, useState } from 'react';

type Kpis = {
  cash_balance: number;
  bank_balance: number;
  receivables_due_today: number;
  payables_due_today: number;
};
type SummaryToday = { sales_total: number; produced_items: number; exchanges_count: number; };

export default function Dashboard() {
  const [kpis, setKpis] = useState<Kpis | null>(null);
  const [summary, setSummary] = useState<SummaryToday | null>(null);
  const API = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3001';

  useEffect(() => {
    fetch(`${API}/dashboard/kpis`).then(r => r.json()).then(d => {
      setKpis(d.kpis);
      setSummary(d.summary_today);
    }).catch(console.error);
  }, []);

  return (
    <main className="space-y-6">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Panisul — Dashboard</h1>
        <div className="space-x-2">
          <button className="btn" onClick={() => alert('Nova Venda (MVP)')}>+ Nova Venda</button>
          <button className="btn" onClick={() => alert('Registrar Produção (MVP)')}>+ Nova Produção</button>
          <button className="btn" onClick={() => alert('Lançar Despesa (MVP)')}>+ Lançar Despesa</button>
          <button className="btn" onClick={() => alert('Importar Compra (MVP)')}>+ Importar</button>
        </div>
      </header>

      <section className="grid-cards">
        <div className="card"><div className="text-sm text-gray-500">Saldo em Caixa</div><div className="text-3xl font-semibold">R$ {kpis?.cash_balance?.toFixed(2) ?? '0,00'}</div></div>
        <div className="card"><div className="text-sm text-gray-500">Saldo em Conta Corrente</div><div className="text-3xl font-semibold">R$ {kpis?.bank_balance?.toFixed(2) ?? '0,00'}</div></div>
        <div className="card"><div className="text-sm text-gray-500">A Receber (Hoje)</div><div className="text-3xl font-semibold">R$ {kpis?.receivables_due_today?.toFixed(2) ?? '0,00'}</div></div>
        <div className="card"><div className="text-sm text-gray-500">A Pagar (Hoje)</div><div className="text-3xl font-semibold">R$ {kpis?.payables_due_today?.toFixed(2) ?? '0,00'}</div></div>
      </section>

      <section className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="card lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">Resumo do Dia</h2>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <div className="text-sm text-gray-500">Vendas (R$)</div>
              <div className="text-2xl font-semibold">{summary?.sales_total?.toFixed(2) ?? '0,00'}</div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Itens Produzidos</div>
              <div className="text-2xl font-semibold">{summary?.produced_items ?? 0}</div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Trocas</div>
              <div className="text-2xl font-semibold">{summary?.exchanges_count ?? 0}</div>
            </div>
          </div>
        </div>
        <div className="card">
          <h2 className="font-semibold mb-2">Alertas</h2>
          <ul className="space-y-2 text-sm text-gray-700">
            <li>Nenhum alerta (MVP)</li>
          </ul>
        </div>
      </section>

      <section>
        <h2 className="font-semibold mb-2">Financeiro Rápido (MVP)</h2>
        <QuickFinance API={API} />
      </section>

      <section>
        <h2 className="font-semibold mb-2">Operação — Produção</h2>
        <ProductionForm API={API} />
      </section>

      <section>
        <h2 className="font-semibold mb-2">Operação — Trocas</h2>
        <ExchangeForm API={API} />
      </section>
    </main>
  );
}


function Section({children}:{children: React.ReactNode}){return <div className="card">{children}</div>}

export function QuickFinance({API}:{API:string}){
  const [amount, setAmount] = useState('100');
  const [supplier, setSupplier] = useState('Fornecedora RS');
  const [cust, setCust] = useState('Cliente XPTO');
  const [date, setDate] = useState(new Date().toISOString().slice(0,10));

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Section>
        <h3 className="font-semibold mb-2">Transferir (Caixa → Conta)</h3>
        <input className="border rounded px-2 py-1 mr-2" value={amount} onChange={e=>setAmount(e.target.value)} />
        <button className="btn" onClick={()=>{
          fetch(`${API}/accounts/transfer`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ fromType:'CASH', toType:'BANK', amount: Number(amount), note:'Depósito diário' })})
            .then(r=>r.json()).then(()=>location.reload()).catch(alert);
        }}>Transferir</button>
      </Section>
      <Section>
        <h3 className="font-semibold mb-2">Novo Pagável</h3>
        <div className="space-x-2">
          <input className="border rounded px-2 py-1" placeholder="Fornecedor" value={supplier} onChange={e=>setSupplier(e.target.value)} />
          <input className="border rounded px-2 py-1" type="date" value={date} onChange={e=>setDate(e.target.value)} />
          <input className="border rounded px-2 py-1 w-24" placeholder="Valor" value={amount} onChange={e=>setAmount(e.target.value)} />
          <button className="btn" onClick={()=>{
            fetch(`${API}/payables`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ supplier, dueDate: date, amount: Number(amount) })})
              .then(r=>r.json()).then(()=>alert('Criado. Faça a baixa via API ou implemente a listagem.')).catch(alert);
          }}>Criar</button>
        </div>
      </Section>
      <Section>
        <h3 className="font-semibold mb-2">Novo Recebível</h3>
        <div className="space-x-2">
          <input className="border rounded px-2 py-1" placeholder="Cliente" value={cust} onChange={e=>setCust(e.target.value)} />
          <input className="border rounded px-2 py-1" type="date" value={date} onChange={e=>setDate(e.target.value)} />
          <input className="border rounded px-2 py-1 w-24" placeholder="Valor" value={amount} onChange={e=>setAmount(e.target.value)} />
          <button className="btn" onClick={()=>{
            fetch(`${API}/receivables`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ customer: cust, dueDate: date, amount: Number(amount) })})
              .then(r=>r.json()).then(()=>alert('Criado. Faça a baixa via API/Insomnia por enquanto.')).catch(alert);
          }}>Criar</button>
        </div>
      </Section>
    </div>
  )
}



type Product = { id: string; name: string; price: number };

function ProductionForm({API}:{API:string}){
  const [products, setProducts] = useState<Product[]>([]);
  const [productId, setProductId] = useState<string>('');
  const [qty, setQty] = useState('100');
  const [losses, setLosses] = useState('0');
  const [result, setResult] = useState<any>(null);

  useEffect(()=>{
    fetch(`${API}/products`).then(r=>r.json()).then((ps:Product[])=>{
      setProducts(ps);
      if (ps.length) setProductId(ps[0].id);
    }).catch(console.error);
  },[]);

  return (
    <div className="card space-y-3">
      <h3 className="font-semibold">Registrar Produção</h3>
      <div className="flex flex-wrap gap-2 items-center">
        <select className="border rounded px-2 py-1" value={productId} onChange={e=>setProductId(e.target.value)}>
          {products.map(p=> <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        <input className="border rounded px-2 py-1 w-28" value={qty} onChange={e=>setQty(e.target.value)} placeholder="Qtd" />
        <input className="border rounded px-2 py-1 w-28" value={losses} onChange={e=>setLosses(e.target.value)} placeholder="Perdas" />
        <button className="btn" onClick={()=>{
          fetch(`${API}/production-batches`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ productId, qtyProduced: Number(qty), qtyLosses: Number(losses) })})
            .then(async r=>{ if(!r.ok){ const t=await r.text(); throw new Error(t); } return r.json(); })
            .then(setResult).catch(e=>alert(e));
        }}>Registrar</button>
      </div>
      {result && (
        <div className="text-sm text-gray-700">
          <div><b>Lote:</b> {result.id}</div>
          <div><b>Produto:</b> {result.product.name} — estoque após: {result.product.stock}</div>
          <div><b>Produzido:</b> {result.produced} | <b>Perdas:</b> {result.losses}</div>
          <div className="mt-2"><b>Ingredientes consumidos:</b></div>
          <ul className="list-disc ml-5">
            {result.consumed.map((c:any)=>(<li key={c.ingredientId}>{c.name}: {c.qty}</li>))}
          </ul>
        </div>
      )}
    </div>
  )
}


function ExchangeForm({API}:{API:string}){
  const [products, setProducts] = useState<Product[]>([]);
  const [productId, setProductId] = useState<string>('');
  const [qty, setQty] = useState('5');
  const [customer, setCustomer] = useState('Cliente XPTO');
  const [reason, setReason] = useState('Troca por defeito');
  const [result, setResult] = useState<any>(null);

  useEffect(()=>{
    fetch(`${API}/products`).then(r=>r.json()).then((ps:Product[])=>{
      setProducts(ps);
      if (ps.length) setProductId(ps[0].id);
    }).catch(console.error);
  },[]);

  return (
    <div className="card space-y-3">
      <h3 className="font-semibold">Registrar Troca</h3>
      <div className="flex flex-wrap gap-2 items-center">
        <input className="border rounded px-2 py-1" placeholder="Cliente" value={customer} onChange={e=>setCustomer(e.target.value)} />
        <select className="border rounded px-2 py-1" value={productId} onChange={e=>setProductId(e.target.value)}>
          {products.map(p=> <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        <input className="border rounded px-2 py-1 w-28" placeholder="Quantidade" value={qty} onChange={e=>setQty(e.target.value)} />
        <input className="border rounded px-2 py-1" placeholder="Motivo" value={reason} onChange={e=>setReason(e.target.value)} />
        <button className="btn" onClick={()=>{
          fetch(`${API}/exchanges`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ customer, productId, qtyOut: Number(qty), reason })})
            .then(async r=>{ if(!r.ok){ const t=await r.text(); throw new Error(t); } return r.json(); })
            .then(setResult).catch(e=>alert(e));
        }}>Registrar</button>
      </div>
      {result && (
        <div className="text-sm text-gray-700">
          <div><b>Troca:</b> {result.id}</div>
          <div><b>Produto:</b> {result.product.name} — estoque após: {result.product.stockAfter}</div>
          <div><b>Despesa (custo):</b> R$ {Number(result.costAmount).toFixed(2)}</div>
          <div>{result.message}</div>
        </div>
      )}
    </div>
  );
}


function SellForm({API}:{API:string}){
  const [products, setProducts] = useState<Product[]>([]);
  const [productId, setProductId] = useState<string>('');
  const [qty, setQty] = useState('10');
  const [method, setMethod] = useState<'CASH'|'PIX'|'CARD'|'ON_CREDIT'>('CASH');
  const [result, setResult] = useState<any>(null);

  useEffect(()=>{
    fetch(`${API}/products`).then(r=>r.json()).then((ps:Product[])=>{
      setProducts(ps);
      if (ps.length) setProductId(ps[0].id);
    }).catch(console.error);
  },[]);

  return (
    <div className="card space-y-3">
      <h3 className="font-semibold">Nova Venda</h3>
      <div className="flex flex-wrap gap-2 items-center">
        <select className="border rounded px-2 py-1" value={productId} onChange={e=>setProductId(e.target.value)}>
          {products.map(p=> <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        <input className="border rounded px-2 py-1 w-24" value={qty} onChange={e=>setQty(e.target.value)} />
        <select className="border rounded px-2 py-1" value={method} onChange={e=>setMethod(e.target.value as any)}>
          <option value="CASH">Dinheiro</option>
          <option value="PIX">PIX</option>
          <option value="CARD">Cartão</option>
          <option value="ON_CREDIT">A Prazo</option>
        </select>
        <button className="btn" onClick={()=>{
          fetch(`${API}/sales`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ items:[{productId, qty: Number(qty)}], payment:{ method } })})
            .then(async r=>{ if(!r.ok){ const t=await r.text(); throw new Error(t); } return r.json(); })
            .then(res=>{ setResult(res); location.reload(); })
            .catch(e=>alert(e));
        }}>Vender</button>
      </div>
      {result && <div className="text-sm text-gray-700">Venda {result.id} registrada — Total R$ {Number(result.total).toFixed(2)} ({result.payment}).</div>}
    </div>
  )
}
