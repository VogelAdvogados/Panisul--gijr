
# Deploy em nuvem (Railway/Render) — Notas Rápidas

## Variáveis (Frontend)
- **NEXT_PUBLIC_API_BASE** = URL pública do Backend (ex.: `https://<backend>.up.railway.app`)

## Variáveis (Backend)
- **PORT** = 3001
- **DATABASE_URL** = `postgresql://panisul:panisul@db:5432/panisul?schema=public` (se usar o Postgres do docker-compose)
  - OU use a URL do Postgres gerenciado (Railway/Render) e **remova** o serviço `db` do `docker-compose.yml` se preferir.

## CORS
- Ajustado para `origin: true`, aceitando domínios do Railway/Render automaticamente.

## Passos (Railway)
1. Suba este repositório para o GitHub.
2. Railway → New Project → Deploy from GitHub → selecione o repositório.
3. Railway detecta **Docker Compose** e sobe os serviços.
4. Após o deploy:
   - Abra o serviço **backend** e copie a URL pública.
   - No serviço **frontend**, configure `NEXT_PUBLIC_API_BASE` com a URL do backend.
   - Redeploy do **frontend**.

## Passos (Render)
1. Crie um Web Service para o **backend** (Dockerfile) e outro para o **frontend**.
2. Configure as variáveis conforme acima.
3. Se usar Postgres gerenciado do Render, aponte `DATABASE_URL` para ele.
