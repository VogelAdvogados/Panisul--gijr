
# Panisul — Sistema de Gestão Integrado (MVP inicial)

Monorepo com **frontend** (Next.js + Tailwind) e **backend** (NestJS + Prisma + PostgreSQL).
Executa via **Docker Compose**.

## Requisitos
- Docker e Docker Compose

## Subir ambiente (dev)
```bash
docker compose up --build
```
Aguarde até:
- **Postgres** em `localhost:5432`
- **Backend** Nest em `http://localhost:3001`
- **Frontend** Next em `http://localhost:3000`

## Variáveis de ambiente
Copie `.env.example` para `.env` nas pastas `backend/` e `frontend/` se desejar customizar.

## Primeiros passos
1. Suba os serviços com `docker compose up --build`.
2. (Opcional) Rodar migrações Prisma manualmente:
   ```bash
   docker compose exec backend npx prisma migrate deploy
   docker compose exec backend npx prisma db seed
   ```

## Estrutura
```
panisul/
  backend/       # API NestJS + Prisma
  frontend/      # Next.js + Tailwind
  docker-compose.yml
```

## Endpoints úteis
- `GET http://localhost:3001/dashboard/kpis` — KPIs (mock + DB-ready)
- `POST http://localhost:3001/sales` — Cria venda simplificada (mock)
- `POST http://localhost:3001/production-batches` — Registra produção (mock)

> Este é um MVP inicial para iterar rapidamente. Os módulos, entidades e regras já estão preparados para expansão conforme o blueprint.
